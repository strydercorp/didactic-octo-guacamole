Chrome extension that plays fullstory sessions all day every day
https://chrome.google.com/webstore/detail/kfonimcgfgogkjhcjflojeifemhljjol/publish-delayed
